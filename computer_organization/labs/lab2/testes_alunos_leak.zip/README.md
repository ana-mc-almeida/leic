Os outputs desejados dependem do estado em que esta a vossa cache em termos de progresso de desenvolvimento: L1 completada, L1 + L2 com 1 via, L1 + L2 com 2 vias

Devem compilar o SimpleProgram.c juntamente com o vosso codigo e executá-lo da seguinte forma e compará-lo com os resultados esperados utilizando o diff
